<?php

    $mysqli = new mysqli("localhost","root","","sistem_alumni");

?>